# /// script
# requires-python = ">=3.12"
# dependencies = ["pandas"]
# ///
"""Execute lecture09_demo.ipynb cells to verify correctness.

Cells tagged with intentional errors are expected to raise: their error
type is asserted rather than swallowing surprises.
"""
import json
import sys
from pathlib import Path

import pandas as pd  # noqa: F401  (populates the env the same way students see it)

NB = Path(__file__).resolve().parent.parent / "lecture09_demo.ipynb"

# Intentional-error cells, keyed by a distinctive substring in the cell.
EXPECTED_ERRORS = {
    "⏸ 故意留错：字符串 + 整数": TypeError,
    "⏸ 故意留错：索引越界": IndexError,
    "⏸ 故意留错：取不存在的键": KeyError,
    "⏸ 故意留错：R用户的三大坑": SyntaxError,
    "⏸ 故意留错：忘括号": pd.errors.InvalidIndexError,
}

nb = json.loads(NB.read_text())
code_cells = [c for c in nb["cells"] if c["cell_type"] == "code"]
print(f"Executing {len(code_cells)} code cells from {NB.name}...\n")

ns: dict = {}
ok = bad = 0
for i, cell in enumerate(code_cells):
    src = "".join(cell["source"])
    tag = next((k for k in EXPECTED_ERRORS if k in src), None)
    try:
        exec(src, ns)  # noqa: S102
    except Exception as e:  # noqa: BLE001
        expected = EXPECTED_ERRORS.get(tag) if tag else None
        if expected is not None:
            assert isinstance(e, expected), (
                f"cell {i}: expected {expected.__name__}, got {type(e).__name__}: {e}"
            )
            print(f"  cell {i:2d} ✗ expected error OK ({type(e).__name__})")
            ok += 1
        else:
            print(f"  cell {i:2d} ✗ UNEXPECTED {type(e).__name__}: {e}")
            print("  ---source---")
            print(src)
            sys.exit(1)
    else:
        assert tag is None, f"cell {i} was expected to raise but didn't: {tag}"
        print(f"  cell {i:2d} ✓")
        ok += 1

# Key assertions against lesson-plan answer key
import pandas as pd
df = pd.read_csv(NB.parent / "demo_data" / "lung_clinical.csv")
print("\n=== answer-key assertions ===")
q2 = df[(df["stage"] == "IV") & (df["smoking"] == "yes")]
assert len(q2) == 9, f"Q2 expected 9 patients, got {len(q2)}"
print(f"Q2 stage-IV smokers: {len(q2)} ✓")
filled_mean = df["egfr_expr"].fillna(df["egfr_expr"].median()).mean()
assert abs(filled_mean - 6.67) < 0.01, f"Q3 expected ~6.67, got {filled_mean}"
print(f"Q3 median-fill mean: {filled_mean:.2f} ✓")

print(f"\nAll {ok} cells OK, 0 unexpected failures.")
