"""Verify lung_clinical.csv works for Lecture 9 demos and homework answers.

Run from the repo root: conda run -n bioinfo python lectures/demo_data/verify_dataset.py
"""
from pathlib import Path

import pandas as pd

df = pd.read_csv(Path(__file__).parent / "lung_clinical.csv")
print("shape:", df.shape)
print(df.info())
print(df.describe())
print("\nhead:\n", df.head())

# Homework answers
n = df[(df["stage"] == "IV") & (df["smoking"] == "yes")].shape[0]
print(f"\nQ2: stage IV & smokers = {n}")

miss = df["egfr_expr"].isnull().sum()
filled_mean = df["egfr_expr"].fillna(df["egfr_expr"].median()).mean()
print(f"Q3: egfr_expr missing = {miss}; mean after median-fill = {filled_mean:.2f}")

# Demo: age_group binning from slide 31
df["age_group"] = pd.cut(df["age"], bins=[0, 50, 70, 120], labels=["<50", "50-70", ">70"])
print("\nage_group counts:\n", df["age_group"].value_counts().sort_index())
