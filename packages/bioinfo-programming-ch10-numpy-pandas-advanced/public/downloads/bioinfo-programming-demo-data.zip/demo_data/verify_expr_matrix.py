# /// script
# requires-python = ">=3.12"
# dependencies = ["pandas", "numpy"]
# ///
"""Generate and verify expr_matrix.csv for Lecture 10 (merge/长宽/分组 demos).

Design (fixed seed, reproducible):
- 28 samples = LC001..LC030 minus LC003/LC027 (sequencing QC dropouts)
- 20 lung-cancer genes, lognormal TPM-like values, 2 decimals
- The 2-sample gap makes merge row-count demos show real differences
"""
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 20261112
HERE = Path(__file__).parent
GENE_BASE = {
    "EGFR": 3.4, "KRAS": 2.9, "ALK": 0.8, "TP53": 4.1, "BRAF": 1.6,
    "MET": 2.2, "ROS1": 0.7, "RET": 1.1, "PIK3CA": 3.0, "STK11": 2.4,
    "KEAP1": 2.6, "ERBB2": 2.1, "NRAS": 2.5, "MAP2K1": 1.9, "DDR2": 1.3,
    "CTNNB1": 3.8, "SMARCA4": 2.8, "CDKN2A": 2.3, "NFE2L2": 2.0, "RIT1": 0.9,
}
GENES = list(GENE_BASE)


def generate() -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    ids = [f"LC{i:03d}" for i in range(1, 31) if i not in (3, 27)]
    base = np.array([GENE_BASE[g] for g in GENES])
    tpm = rng.lognormal(mean=base, sigma=1.0, size=(len(ids), len(GENES)))
    df = pd.DataFrame(np.round(tpm, 2), columns=GENES)
    df.insert(0, "patient_id", ids)
    return df


def verify(expr: pd.DataFrame, clin: pd.DataFrame) -> None:
    assert expr.shape == (28, 21), f"shape {expr.shape} != (28, 21)"
    assert list(expr.columns) == ["patient_id"] + GENES
    assert not expr.isnull().any().any(), "unexpected missing values"
    assert (expr[GENES] > 0).all().all(), "TPM values must be positive"
    assert "LC003" not in set(expr["patient_id"])
    assert "LC027" not in set(expr["patient_id"])
    assert set(expr["patient_id"]) <= set(clin["patient_id"]), "expr IDs must exist in clin"
    print("expr_matrix.csv:", expr.shape, "| seed", SEED)
    print("missing samples:", sorted(set(clin["patient_id"]) - set(expr["patient_id"])))
    print(expr.head(3).to_string(index=False))

    print("\nmerge row counts vs lung_clinical.csv (30):")
    for how in ("inner", "left", "right", "outer"):
        expr_left = pd.merge(expr, clin, on="patient_id", how=how)
        clin_left = pd.merge(clin, expr, on="patient_id", how=how)
        print(f"  how={how:5s}: expr← {len(expr_left):2d} | clin← {len(clin_left):2d}")
    filled = pd.merge(clin, expr, on="patient_id", how="left")
    print("clin-left rows with all-NaN expression:", int(filled[GENES[0]].isnull().sum()))
    assert len(pd.merge(expr, clin, on="patient_id", how="inner")) == 28
    assert len(filled) == 30
    print("\nOK: expr_matrix.csv matches the lesson design")


if __name__ == "__main__":
    out = HERE / "expr_matrix.csv"
    frame = generate()
    frame.to_csv(out, index=False)
    clin = pd.read_csv(HERE / "lung_clinical.csv")
    verify(pd.read_csv(out), clin)
